from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import FoodViewSet, FoodTypeViewSet, CommentViewSet

router = DefaultRouter()
router.register("foods", FoodViewSet, basename="food")
router.register("foodtypes", FoodTypeViewSet, basename="foodtype")
router.register("comments", CommentViewSet, basename="comment")

urlpatterns = [
    path("", include(router.urls)),
]
